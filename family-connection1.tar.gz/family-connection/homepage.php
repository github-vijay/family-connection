<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
<button><a href="select.php">Select</a></button>
<button><a href="insert.php">Insert</a></button>
<button><a href="delete.php">Delete</a></button>
<button><a href="update.php">Update</a></button>
<button><a href="create.php">Create</a></button>
</body>
</html>