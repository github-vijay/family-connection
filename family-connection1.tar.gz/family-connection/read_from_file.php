<?php
$homepage = file_get_contents('people.txt');
echo $homepage;
?>
